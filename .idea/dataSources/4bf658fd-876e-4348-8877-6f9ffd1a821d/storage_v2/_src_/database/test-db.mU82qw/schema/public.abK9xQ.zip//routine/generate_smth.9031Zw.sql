create function generate_smth() returns void
    language plpgsql
as
$$
DECLARE BEGIN  FOR i IN 1..100000 LOOP
INSERT INTO numbers values (random());
END LOOP;
END;
$$;

alter function generate_smth() owner to eric;

